package de.paperclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class PaperMenuScreen extends Screen {
    public PaperMenuScreen() { super(Text.literal("Paper Client")); }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 - 50;
        addToggle(cx - 100, y,      "Fullbright", () -> PaperClient.fullbright, v -> PaperClient.fullbright = v);
        addToggle(cx - 100, y + 26, "HUD",        () -> PaperClient.hud,        v -> PaperClient.hud = v);
        addToggle(cx - 100, y + 52, "Koordinaten",() -> PaperClient.coords,     v -> PaperClient.coords = v);
        addToggle(cx - 100, y + 78, "FPS-Anzeige",() -> PaperClient.fps,        v -> PaperClient.fps = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Schließen"), b -> close())
                .dimensions(cx - 100, y + 112, 200, 20).build());
    }

    private void addToggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, 200, 20).build());
    }

    private Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "AN" : "AUS"));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xFF000000, 0xFF2A0A3D);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cx = width / 2;
        ctx.fill(cx - 110, height / 2 - 80, cx + 110, height / 2 - 78, PaperClient.RED);
        ctx.drawCenteredTextWithShadow(textRenderer, "PAPER CLIENT", cx, height / 2 - 70, PaperClient.PURPLE);
    }
}
