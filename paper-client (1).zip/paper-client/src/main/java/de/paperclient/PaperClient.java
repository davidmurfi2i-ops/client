package de.paperclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

public class PaperClient implements ClientModInitializer {
    // Farben (ARGB)
    public static final int BLACK  = 0xFF0A0A0A;
    public static final int PURPLE = 0xFF9B30FF;
    public static final int RED    = 0xFFE01B24;
    public static final int WHITE  = 0xFFFFFFFF;

    // Module
    public static boolean fullbright = true;
    public static boolean hud = true;
    public static boolean coords = true;
    public static boolean fps = true;

    private static KeyBinding menuKey;
    private static KeyBinding fullbrightKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.paperclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.paperclient"));
        fullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.paperclient.fullbright", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.paperclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new PaperMenuScreen());
            while (fullbrightKey.wasPressed()) fullbright = !fullbright;
            applyFullbright(client);
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!hud || mc.player == null || mc.options.hudHidden) return;
            var tr = mc.textRenderer;
            int x = 6, y = 6;
            String title = "Paper Client";
            int w = tr.getWidth(title) + 12;
            ctx.fill(x, y, x + w, y + 14, 0xCC000000);
            ctx.fill(x, y, x + 2, y + 14, PURPLE);
            ctx.fill(x, y + 14, x + w, y + 15, RED);
            ctx.drawTextWithShadow(tr, title, x + 6, y + 3, PURPLE);
            y += 19;
            if (fps) { ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", x + 2, y, RED); y += 11; }
            if (coords) {
                String c = String.format("XYZ %d / %d / %d", (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
                ctx.drawTextWithShadow(tr, c, x + 2, y, WHITE);
            }
        });
    }

    private static void applyFullbright(MinecraftClient client) {
        if (client.player == null) return;
        if (fullbright) {
            client.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        } else {
            var inst = client.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (inst != null && inst.getDuration() <= 400 && !inst.shouldShowParticles() && !inst.shouldShowIcon()) {
                client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }
        }
    }
}
