package de.paperclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class PaperTitleScreen extends Screen {
    public PaperTitleScreen() { super(Text.literal("Paper Client")); }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 - 10;
        addDrawableChild(ButtonWidget.builder(Text.literal("Einzelspieler"),
                b -> client.setScreen(new SelectWorldScreen(this))).dimensions(cx - 100, y, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Mehrspieler"),
                b -> client.setScreen(new MultiplayerScreen(this))).dimensions(cx - 100, y + 24, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Paper Client Menü"),
                b -> client.setScreen(new PaperMenuScreen())).dimensions(cx - 100, y + 48, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Optionen"),
                b -> client.setScreen(new OptionsScreen(this, client.options))).dimensions(cx - 100, y + 72, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Beenden"),
                b -> client.scheduleStop()).dimensions(cx + 2, y + 72, 98, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xFF000000, 0xFF3A0A4F);
        ctx.fill(0, height - 3, width, height, PaperClient.RED);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        var m = ctx.getMatrices();
        m.push();
        m.translate(width / 2f, height / 2f - 70, 0);
        m.scale(4f, 4f, 1f);
        ctx.drawCenteredTextWithShadow(textRenderer, "PAPER", -22, 0, PaperClient.PURPLE);
        ctx.drawCenteredTextWithShadow(textRenderer, "CLIENT", 24, 0, PaperClient.RED);
        m.pop();
        ctx.drawCenteredTextWithShadow(textRenderer, "Rechts-Shift = Menü  |  V = Fullbright", width / 2, height - 16, 0xFFAAAAAA);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
